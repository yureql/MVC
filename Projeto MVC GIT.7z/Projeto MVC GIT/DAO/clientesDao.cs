﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Modell;
using System.Data.SqlClient;

namespace DAO
{
    public class clientesDao
    {
             
        public clientesDao() {
            BD conexaoDao = new BD();
        }
        //metodo para inserir clientes no banco
        public Boolean salvar(clientesModell cliM) {
            //abrir a conexao
            SqlConnection conn = BD.abrirConexao();
            //string para inserção
            string sql = "INSERT INTO clientes (nome, telefone, cpf, sexo, endereco) VALUES (@nome,@telefone,@cpf,@sexo,@endereco)";
            try
            {
                //criar um objeto passando a conexao e a sql inserção
                SqlCommand comando = new SqlCommand(sql, conn);
                //adicionando os valores a sql
                comando.Parameters.AddWithValue("@nome", cliM.Nome);
                comando.Parameters.AddWithValue("@telefone", cliM.Telefone);
                comando.Parameters.AddWithValue("@cpf", cliM.Cpf);
                comando.Parameters.AddWithValue("@sexo", cliM.Sexo);
                comando.Parameters.AddWithValue("@endereco", cliM.Endereco);
                //abrir a conexao
                BD.abrirConexao();
                //executar os comandos
                comando.ExecuteNonQuery();
                //fechar a conexao
                BD.fecharConexao();
                return true;
            }
            catch (SqlException erro)
            {
                Console.WriteLine("Erro ao inserir dados no banco" + erro);
                return false;
            }
            finally {
                BD.fecharConexao();
            }            
            
        }
        //metodo para carregar a datagridview
        public List<clientesModell> CarregarGridDao(string strWhere)
        {
            List<clientesModell> listaclientes = new List<clientesModell>();
            clientesModell clientes = null;

            if (!string.IsNullOrWhiteSpace(strWhere))
                strWhere = " WHERE " + strWhere;
          
            //StringBuilder usada para concatenar strings
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT id, nome, telefone, cpf, sexo, endereco FROM clientes ")
              .Append("" + strWhere + " ")              
              .Append("ORDER BY id");
            //String sql = "SELECT id, nome, telefone, cpf, sexo, endereco FROM clientes";

            SqlConnection conn = BD.abrirConexao();
            SqlCommand cmd = new SqlCommand(sb.ToString(), conn);

                try
                {
                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        clientes = new clientesModell();

                        if (dr["id"] != DBNull.Value)
                            clientes.Id = Convert.ToInt32(dr["id"]);
                    
                        if (dr["nome"] != DBNull.Value)
                            clientes.Nome = (dr["nome"].ToString());

                        if (dr["telefone"] != DBNull.Value)
                            clientes.Telefone = (dr["telefone"].ToString());

                        if (dr["cpf"] != DBNull.Value)
                            clientes.Cpf = dr["cpf"].ToString();

                        if (dr["sexo"] != DBNull.Value)
                            clientes.Sexo = Convert.ToChar(dr["sexo"]);

                        if (dr["endereco"] != DBNull.Value)
                            clientes.Endereco = (dr["endereco"].ToString());

                    if (listaclientes == null)
                            listaclientes = new List<clientesModell>();

                        listaclientes.Add(clientes);
                    }

                    return listaclientes;
                }
                catch (SqlException erro)
                {
                    Console.WriteLine("Erro ao pesquisar dados no banco" + erro);
                    return listaclientes;
                }
                finally
                {
                    BD.fecharConexao();
                }
        }

        //metodo para carregar a datagridview
        public int ExcluirClienteDao(int id_cliente)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("DELETE FROM [clientes]")
              .Append("WHERE [id] = @ID");

            SqlConnection conn = BD.abrirConexao();

            try
            {                
                    SqlCommand cmd = new SqlCommand(sb.ToString(), conn);
                    cmd.Parameters.AddWithValue("@ID", id_cliente);
                    return Convert.ToInt32(cmd.ExecuteNonQuery());                
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

        //metodo para alterar o cliente
        public int AlterarClienteDao(clientesModell cliM)
        {
            //abrir a conexao
            SqlConnection conn = BD.abrirConexao();
            //string para inserção
            string sql = "UPDATE clientes SET nome = @nome, telefone = @telefone, cpf = @cpf,sexo = @sexo, endereco = @endereco where id = @id";
            try
            {
                //criar um objeto passando a conexao e a sql inserção
                SqlCommand comando = new SqlCommand(sql, conn);
                //adicionando os valores a sql
                comando.Parameters.AddWithValue("@nome", cliM.Nome);
                comando.Parameters.AddWithValue("@telefone", cliM.Telefone);
                comando.Parameters.AddWithValue("@cpf", cliM.Cpf);
                comando.Parameters.AddWithValue("@sexo", cliM.Sexo);
                comando.Parameters.AddWithValue("@endereco", cliM.Endereco);
                comando.Parameters.AddWithValue("@id",cliM.Id);
                //abrir a conexao
                BD.abrirConexao();
                //executar os comandos
                comando.ExecuteNonQuery();
                //fechar a conexao
                BD.fecharConexao();
                return Convert.ToInt32(comando.ExecuteNonQuery());

            }
            catch (SqlException erro)
            {
                Console.WriteLine("Erro ao alterar dados no banco" + erro);
                return 0;
            }
            finally
            {
                BD.fecharConexao();
            }  
        }
    }
}
