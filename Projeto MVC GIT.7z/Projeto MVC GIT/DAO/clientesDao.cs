﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Modell;
using System.Data.SqlClient;

namespace DAO
{
    public class clientesDao
    {
             
        public clientesDao() {
            BD conexaoDao = new BD();
        }
        //metodo para inserir clientes no banco
        public Boolean salvar(clientesModell cliM) {
            //abrir a conexao
            SqlConnection conn = BD.abrirConexao();
            //string para inserção
            string sql = "INSERT INTO clientes (nome, telefone, cpf, sexo, endereco) VALUES (@nome,@telefone,@cpf,@sexo,@endereco)";
            try
            {
                //criar um objeto passando a conexao e a sql inserção
                SqlCommand comando = new SqlCommand(sql, conn);
                //adicionando os valores a sql
                comando.Parameters.AddWithValue("@nome", cliM.Nome);
                comando.Parameters.AddWithValue("@telefone", cliM.Telefone);
                comando.Parameters.AddWithValue("@cpf", cliM.Cpf);
                comando.Parameters.AddWithValue("@sexo", cliM.Sexo);
                comando.Parameters.AddWithValue("@endereco", cliM.Endereco);
                //abrir a conexao
                BD.abrirConexao();
                //executar os comandos
                comando.ExecuteNonQuery();
                //fechar a conexao
                BD.fecharConexao();
                return true;
            }
            catch (SqlException erro)
            {
                Console.WriteLine("Erro ao inserir dados no banco" + erro);
                return false;
            }
            finally {
                BD.fecharConexao();
            }            
            
        }
        //metodo para carregar a datagridview
        public List<clientesModell> CarregarGrid(string strWhere)
        {
            List<clientesModell> listausuario = new List<clientesModell>();
            clientesModell usuario = null;

            if (!string.IsNullOrWhiteSpace(strWhere))
                strWhere = " WHERE " + strWhere;

            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT id, nome, telefone, cpf, sexo, endereco FROM clientes ")
              .Append("" + strWhere + " ")
              .Append("ORDER BY id");

           // SqlConnection conn = BD.abrirConexao();//Funcoes.ConexaoBD.RetornaConexaoBD()

            SqlConnection conn = BD.abrirConexao();
            SqlCommand cmd = new SqlCommand(sb.ToString(), conn);

                try
                {
                    conn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        usuario = new clientesModell();

                        if (dr["id"] != DBNull.Value)
                            usuario.Id = Convert.ToInt32(dr["id"]);

                        if (dr["nome"] != DBNull.Value)
                            usuario.Nome = (dr["nome"].ToString());

                        if (dr["telefone"] != DBNull.Value)
                            usuario.Telefone = (dr["telefone"].ToString());

                        if (dr["cpf"] != DBNull.Value)
                            usuario.Cpf = dr["cpf"].ToString();

                        if (dr["sexo"] != DBNull.Value)
                            usuario.Sexo = Convert.ToChar(dr["sexo"]);

                        if (listausuario == null)
                            listausuario = new List<clientesModell>();

                        listausuario.Add(usuario);
                    }

                    return listausuario;
                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            
        }

    }
}
