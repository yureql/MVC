﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace DAO
{
    public static class usuarioDao
    {
        public static Boolean verificarUsuarioBanco(string usuario, string senha)
        {
            //abrir a conexao
            SqlConnection conn = BD.abrirConexao();
            SqlDataReader dr; //objeto para receber o retorno do banco
            //string para pesquisa de usuario no banco
            string sql = "select nomeusuario from usuarios where nomeusuario = @usuario and senhausuario = @senha";
            try
            {
                //criar um objeto passando a conexao e a sql inserção
                SqlCommand comando = new SqlCommand(sql, conn);
                //adicionando os valores a sql
                comando.Parameters.AddWithValue("@usuario", usuario);
                comando.Parameters.AddWithValue("@senha", senha);
                //abrir a conexao
                BD.abrirConexao();
                //executar os comandos
                dr = comando.ExecuteReader();//Usado para quando a conexão retorna valores nesse caso usamos um select
                //fechar a conexao
                if (dr.HasRows) { //se foi encontrada linha com os dados enviados
                    return true;
                }
                else {
                    return false;
                }               
            }
            catch (SqlException erro)
            {
                Console.WriteLine("Erro ao inserir dados no banco" + erro);
                return false;
            }
            finally
            {
                BD.fecharConexao();
            }
        }
    }
}
