﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modell
{
    class UsuarioModell
    {
        private int idUsuario;
        private String nomeUsuario;
        private String senhaUsuario;
        private String cpfUsuario;

        public int IdUsuario { get => idUsuario; set => idUsuario = value; }
        public string NomeUsuario { get => nomeUsuario; set => nomeUsuario = value; }
        public string SenhaUsuario { get => senhaUsuario; set => senhaUsuario = value; }
        public string CpfUsuario { get => cpfUsuario; set => cpfUsuario = value; }
                
    }
}
