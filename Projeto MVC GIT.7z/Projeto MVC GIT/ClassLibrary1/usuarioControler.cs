﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Modell;
using DAO;

namespace Controler
{
    public class usuarioControler
    {       
        public Boolean autenticarUsuario(string usuario, string senha)
        {
            if (usuarioDao.verificarUsuarioBanco(usuario, senha))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
