﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Modell;
using DAO;

namespace Controler
{
    public class clientesControler
    {
       public static Boolean salvarCli(clientesModell cliente) {
            clientesDao cliDao = new clientesDao();
            try
            {
                return cliDao.salvar(cliente);
            }
            catch (Exception erro)
            {
                Console.WriteLine($"{erro} erro ao salvar cliente no Controler. ");
                return false;
            }
        }

        public List<clientesModell> CarregarGrid(string strWhere)
        {
            return new DAO.clientesDao().CarregarGridDao(strWhere);           
        }

        public int ExcluirCliente(int id)
        {
            return new DAO.clientesDao().ExcluirClienteDao(id);
        }

        public int AlterarCliente(clientesModell cliente)
        {
            return new DAO.clientesDao().AlterarClienteDao(cliente);
        }

    }
}
