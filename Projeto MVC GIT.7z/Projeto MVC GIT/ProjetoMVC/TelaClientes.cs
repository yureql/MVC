﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Modell;
using Controler;
using System.Data.SqlClient;
using DAO;

namespace ProjetoMVC
{
    public partial class TelaCliente : Form
    {
        public TelaCliente()
        {
            InitializeComponent();
        }

        private void CarregaGridClientes() {
            string strWhere = " ";
            List<clientesModell> listaclientes = new clientesControler().CarregarGrid(strWhere);
            //dataGridViewClientes2.AutoGenerateColumns = false;
            dataGridViewClientes2.DataSource = listaclientes;
            dataGridViewClientes2.RowsDefaultCellStyle.BackColor = Color.White;
            dataGridViewClientes2.AlternatingRowsDefaultCellStyle.BackColor = Color.Lavender;
        }

        clientesModell clienteM = new clientesModell();
        private void btnSalvarClientes_Click(object sender, EventArgs e)
        {
            clienteM.Nome = this.tbNome.Text;
            clienteM.Telefone = this.tbTelefone.Text;
            clienteM.Sexo = char.Parse(this.tbSexo.Text);
            clienteM.Endereco = this.tbEndereco.Text;
            clienteM.Cpf = this.tbCpf.Text;

            if (clientesControler.salvarCli(clienteM))
            {
                MessageBox.Show("Dados salvos com Sucesso!");
                this.tbNome.Text = "";
                this.tbTelefone.Text = "";
                this.tbEndereco.Text = "";
                this.tbSexo.Text = "";
                this.tbCpf.Text = "";
                CarregaGridClientes();
            }
            else
            {
                MessageBox.Show("Erro ao salvar os dados!");
            }
        }

        private void btnPesquisarClientes_Click(object sender, EventArgs e)
        {
            CarregaGridClientes();
        }

        private void btnExcluirClientes_Click(object sender, EventArgs e)
        {
            clientesModell clientes = new clientesModell();
            //recuperando o id no datagrid
            clientes.Id = int.Parse(dataGridViewClientes2.CurrentRow.Cells[0].Value.ToString());
            new clientesControler().ExcluirCliente(Convert.ToInt32(clientes.Id));
            CarregaGridClientes();
        }

        private void btnAlterarClientes_Click(object sender, EventArgs e)
        {
            clientesModell clientes = new clientesModell();

            clientes.Id = int.Parse(dataGridViewClientes2.CurrentRow.Cells[0].Value.ToString());
            clientes.Nome = (dataGridViewClientes2.CurrentRow.Cells[1].Value.ToString());
            clientes.Telefone = (dataGridViewClientes2.CurrentRow.Cells[2].Value.ToString());
            clientes.Cpf = (dataGridViewClientes2.CurrentRow.Cells[3].Value.ToString());
            clientes.Sexo = char.Parse(dataGridViewClientes2.CurrentRow.Cells[4].Value.ToString());
            clientes.Endereco = (dataGridViewClientes2.CurrentRow.Cells[5].Value.ToString());
            new clientesControler().AlterarCliente(clientes);
            CarregaGridClientes();
        }

    }

}
