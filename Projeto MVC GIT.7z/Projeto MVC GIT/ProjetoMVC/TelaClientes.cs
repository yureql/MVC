﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Modell;
using Controler;
using System.Data.SqlClient;
using DAO;

namespace ProjetoMVC
{
    public partial class TelaCliente : Form
    {
        public TelaCliente()
        {
            InitializeComponent();
        }

        clientesModell clienteM = new clientesModell();
        private void btnSalvarClientes_Click(object sender, EventArgs e)
        {
            clienteM.Nome = this.tbNome.Text;
            clienteM.Telefone = this.tbTelefone.Text;
            clienteM.Sexo = char.Parse(this.tbSexo.Text);
            clienteM.Endereco = this.tbEndereco.Text;
            clienteM.Cpf = this.tbCpf.Text;

            if (clientesControler.salvarCli(clienteM))
            {
                MessageBox.Show("Dados salvos com Sucesso!");
                this.tbNome.Text = "";
                this.tbTelefone.Text = "";
                this.tbEndereco.Text = "";
                this.tbSexo.Text = "";
                this.tbCpf.Text = "";
            }
            else
            {
                MessageBox.Show("Erro ao salvar os dados!");
            }
        }

        private void btnPesquisarClientes_Click(object sender, EventArgs e)
        {
            SqlConnection conn = BD.abrirConexao();
             string sql = "select * from clientes";
             using (SqlDataAdapter da = new SqlDataAdapter(sql,conn)) {
                 using (DataTable dt = new DataTable()) {
                     da.Fill(dt);
                     dataGridViewClientes.DataSource = dt;
                 }
             }
           
            /*string strWhere = "";            
            List<clientesModell> listausuario = new clientesControler().CarregarGrid(strWhere);
            dataGridViewClientes2.AutoGenerateColumns = false;
            dataGridViewClientes2.DataSource = listausuario;
            dataGridViewClientes2.RowsDefaultCellStyle.BackColor = Color.White;
            dataGridViewClientes2.AlternatingRowsDefaultCellStyle.BackColor = Color.Lavender;*/

        }

    }

}
