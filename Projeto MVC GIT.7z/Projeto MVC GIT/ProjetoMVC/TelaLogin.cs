﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;//para janelas
using Controler;

namespace ProjetoMVC
{
    public partial class TelaLogin : Form
    {
        clientesControler clientesControler = new clientesControler();
        usuarioControler usuario = new usuarioControler();
        Thread tela;
        
        public TelaLogin()
        {
            InitializeComponent();
        }

        private void btnLogar_Click(object sender, EventArgs e)
        {
            if (this.tbUsuario.Text == "" || this.tbSenha.Text == "")
            {
                MessageBox.Show("Campo em branco! Favor digitar USUÁRIO e SENHA.");
            }
            else {                

                if (usuario.autenticarUsuario(this.tbUsuario.Text, this.tbSenha.Text)) {
                    /*MessageBox.Show("Login Realizado Com Sucesso!");
                    //chamar a tela de clientes caso login seja valido
                    TelaCliente tl = new TelaCliente();
                    tl.Show();
                    //this.Hide();//esconder a tela problema*/
                    
                    //Usando Thread
                    this.Close();
                    tela = new Thread(abrirJanelaCliente);
                    tela.SetApartmentState(ApartmentState.STA);
                    tela.Start();
                }
                else {
                    MessageBox.Show("Usuário ou senha incorretos!");
                }
            }
        }
        //Metodo para fechar a tela ao clicar no botão cancelar
        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //metodo para abrir janela
        private void abrirJanelaCliente(object obj) {
            Application.Run(new TelaCliente());
        }

        private void btnCadastrarUsuario_Click(object sender, EventArgs e)
        {

        }
    }
}
