﻿
namespace ProjetoMVC
{
    partial class TelaCliente
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbNome = new System.Windows.Forms.TextBox();
            this.tbCpf = new System.Windows.Forms.TextBox();
            this.tbTelefone = new System.Windows.Forms.TextBox();
            this.tbSexo = new System.Windows.Forms.TextBox();
            this.tbEndereco = new System.Windows.Forms.TextBox();
            this.btnSalvarClientes = new System.Windows.Forms.Button();
            this.btnAlterarClientes = new System.Windows.Forms.Button();
            this.btnExcluirClientes = new System.Windows.Forms.Button();
            this.btnPesquisarClientes = new System.Windows.Forms.Button();
            this.dataGridViewClientes = new System.Windows.Forms.DataGridView();
            this.dataGridViewClientes2 = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NOME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TELEFONE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CPF = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SEXO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ENDERECO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClientes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClientes2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "CPF:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Telefone:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 127);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Sexo:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 164);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Endereço:";
            // 
            // tbNome
            // 
            this.tbNome.Location = new System.Drawing.Point(90, 25);
            this.tbNome.Name = "tbNome";
            this.tbNome.Size = new System.Drawing.Size(269, 20);
            this.tbNome.TabIndex = 5;
            // 
            // tbCpf
            // 
            this.tbCpf.Location = new System.Drawing.Point(90, 56);
            this.tbCpf.Name = "tbCpf";
            this.tbCpf.Size = new System.Drawing.Size(269, 20);
            this.tbCpf.TabIndex = 6;
            // 
            // tbTelefone
            // 
            this.tbTelefone.Location = new System.Drawing.Point(90, 90);
            this.tbTelefone.Name = "tbTelefone";
            this.tbTelefone.Size = new System.Drawing.Size(269, 20);
            this.tbTelefone.TabIndex = 7;
            // 
            // tbSexo
            // 
            this.tbSexo.Location = new System.Drawing.Point(90, 127);
            this.tbSexo.Name = "tbSexo";
            this.tbSexo.Size = new System.Drawing.Size(269, 20);
            this.tbSexo.TabIndex = 8;
            // 
            // tbEndereco
            // 
            this.tbEndereco.Location = new System.Drawing.Point(90, 164);
            this.tbEndereco.Name = "tbEndereco";
            this.tbEndereco.Size = new System.Drawing.Size(269, 20);
            this.tbEndereco.TabIndex = 9;
            // 
            // btnSalvarClientes
            // 
            this.btnSalvarClientes.Location = new System.Drawing.Point(31, 211);
            this.btnSalvarClientes.Name = "btnSalvarClientes";
            this.btnSalvarClientes.Size = new System.Drawing.Size(75, 23);
            this.btnSalvarClientes.TabIndex = 10;
            this.btnSalvarClientes.Text = "Salvar";
            this.btnSalvarClientes.UseVisualStyleBackColor = true;
            this.btnSalvarClientes.Click += new System.EventHandler(this.btnSalvarClientes_Click);
            // 
            // btnAlterarClientes
            // 
            this.btnAlterarClientes.Location = new System.Drawing.Point(129, 211);
            this.btnAlterarClientes.Name = "btnAlterarClientes";
            this.btnAlterarClientes.Size = new System.Drawing.Size(75, 23);
            this.btnAlterarClientes.TabIndex = 11;
            this.btnAlterarClientes.Text = "Alterar";
            this.btnAlterarClientes.UseVisualStyleBackColor = true;
            // 
            // btnExcluirClientes
            // 
            this.btnExcluirClientes.Location = new System.Drawing.Point(250, 211);
            this.btnExcluirClientes.Name = "btnExcluirClientes";
            this.btnExcluirClientes.Size = new System.Drawing.Size(75, 23);
            this.btnExcluirClientes.TabIndex = 12;
            this.btnExcluirClientes.Text = "Excluir";
            this.btnExcluirClientes.UseVisualStyleBackColor = true;
            // 
            // btnPesquisarClientes
            // 
            this.btnPesquisarClientes.Location = new System.Drawing.Point(359, 211);
            this.btnPesquisarClientes.Name = "btnPesquisarClientes";
            this.btnPesquisarClientes.Size = new System.Drawing.Size(75, 23);
            this.btnPesquisarClientes.TabIndex = 13;
            this.btnPesquisarClientes.Text = "Pesquisar";
            this.btnPesquisarClientes.UseVisualStyleBackColor = true;
            this.btnPesquisarClientes.Click += new System.EventHandler(this.btnPesquisarClientes_Click);
            // 
            // dataGridViewClientes
            // 
            this.dataGridViewClientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewClientes.Location = new System.Drawing.Point(12, 260);
            this.dataGridViewClientes.Name = "dataGridViewClientes";
            this.dataGridViewClientes.Size = new System.Drawing.Size(569, 150);
            this.dataGridViewClientes.TabIndex = 14;
            // 
            // dataGridViewClientes2
            // 
            this.dataGridViewClientes2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewClientes2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.NOME,
            this.TELEFONE,
            this.CPF,
            this.SEXO,
            this.ENDERECO});
            this.dataGridViewClientes2.Location = new System.Drawing.Point(31, 508);
            this.dataGridViewClientes2.Name = "dataGridViewClientes2";
            this.dataGridViewClientes2.Size = new System.Drawing.Size(640, 150);
            this.dataGridViewClientes2.TabIndex = 15;
            // 
            // ID
            // 
            this.ID.DataPropertyName = "id";
            this.ID.HeaderText = "id";
            this.ID.Name = "ID";
            // 
            // NOME
            // 
            this.NOME.DataPropertyName = "nome";
            this.NOME.HeaderText = "nome";
            this.NOME.Name = "NOME";
            // 
            // TELEFONE
            // 
            this.TELEFONE.DataPropertyName = "telefone";
            this.TELEFONE.HeaderText = "telefone";
            this.TELEFONE.Name = "TELEFONE";
            // 
            // CPF
            // 
            this.CPF.DataPropertyName = "cpf";
            this.CPF.HeaderText = "cpf";
            this.CPF.Name = "CPF";
            // 
            // SEXO
            // 
            this.SEXO.DataPropertyName = "sexo";
            this.SEXO.HeaderText = "sexo";
            this.SEXO.Name = "SEXO";
            // 
            // ENDERECO
            // 
            this.ENDERECO.DataPropertyName = "endereco";
            this.ENDERECO.HeaderText = "endereco";
            this.ENDERECO.Name = "ENDERECO";
            // 
            // TelaCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(832, 678);
            this.Controls.Add(this.dataGridViewClientes2);
            this.Controls.Add(this.dataGridViewClientes);
            this.Controls.Add(this.btnPesquisarClientes);
            this.Controls.Add(this.btnExcluirClientes);
            this.Controls.Add(this.btnAlterarClientes);
            this.Controls.Add(this.btnSalvarClientes);
            this.Controls.Add(this.tbEndereco);
            this.Controls.Add(this.tbSexo);
            this.Controls.Add(this.tbTelefone);
            this.Controls.Add(this.tbCpf);
            this.Controls.Add(this.tbNome);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "TelaCliente";
            this.Text = "CLIENTES";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClientes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClientes2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbNome;
        private System.Windows.Forms.TextBox tbCpf;
        private System.Windows.Forms.TextBox tbTelefone;
        private System.Windows.Forms.TextBox tbSexo;
        private System.Windows.Forms.TextBox tbEndereco;
        private System.Windows.Forms.Button btnSalvarClientes;
        private System.Windows.Forms.Button btnAlterarClientes;
        private System.Windows.Forms.Button btnExcluirClientes;
        private System.Windows.Forms.Button btnPesquisarClientes;
        private System.Windows.Forms.DataGridView dataGridViewClientes;
        private System.Windows.Forms.DataGridView dataGridViewClientes2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn NOME;
        private System.Windows.Forms.DataGridViewTextBoxColumn TELEFONE;
        private System.Windows.Forms.DataGridViewTextBoxColumn CPF;
        private System.Windows.Forms.DataGridViewTextBoxColumn SEXO;
        private System.Windows.Forms.DataGridViewTextBoxColumn ENDERECO;
    }
}

